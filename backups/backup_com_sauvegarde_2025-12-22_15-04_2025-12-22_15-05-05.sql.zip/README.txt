Backup complet
Date: 2025-12-22 15:05:12
Base: backup_com_sauvegarde_2025-12-22_15-04_2025-12-22_15-05-05.sql_db.sql
Fichiers: backup_com_sauvegarde_2025-12-22_15-04_2025-12-22_15-05-05.sql_files.zip
