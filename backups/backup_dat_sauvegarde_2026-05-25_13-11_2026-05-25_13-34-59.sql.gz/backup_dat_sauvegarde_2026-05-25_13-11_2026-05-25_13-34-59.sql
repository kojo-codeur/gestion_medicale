-- Backup de la base de données
-- Généré le: 2026-05-25 13:34:59
-- Base: gestion_medicale

SET FOREIGN_KEY_CHECKS=0;

--
-- Structure de la table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `old_values` text,
  `new_values` text,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_table` (`table_name`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `audit_logs`
--

INSERT INTO `audit_logs` VALUES ('1', '2', 'UPDATE_PROFILE', 'utilisateurs', '2', NULL, NULL, '::1', NULL, '2025-12-22 21:11:24');
INSERT INTO `audit_logs` VALUES ('2', '6', 'UPDATE_PROFILE', 'utilisateurs', '6', NULL, NULL, '::1', NULL, '2025-12-23 14:51:22');
INSERT INTO `audit_logs` VALUES ('3', '1', 'DOWNLOAD_BACKUP', 'backup_history', '1', NULL, NULL, NULL, NULL, '2025-12-24 00:58:03');
INSERT INTO `audit_logs` VALUES ('4', '10', 'REGISTER', 'utilisateurs', '10', NULL, NULL, '::1', NULL, '2025-12-25 00:09:46');
INSERT INTO `audit_logs` VALUES ('5', '1', 'UPDATE', 'utilisateurs', '10', NULL, NULL, '::1', NULL, '2025-12-25 00:48:07');
INSERT INTO `audit_logs` VALUES ('6', '1', 'UPDATE', 'utilisateurs', '9', NULL, NULL, '::1', NULL, '2025-12-25 00:50:17');
INSERT INTO `audit_logs` VALUES ('7', '1', 'UPDATE', 'utilisateurs', '8', NULL, NULL, '::1', NULL, '2025-12-25 00:50:22');
INSERT INTO `audit_logs` VALUES ('8', '1', 'UPDATE', 'utilisateurs', '8', NULL, NULL, '::1', NULL, '2025-12-25 00:50:57');
INSERT INTO `audit_logs` VALUES ('9', '1', 'UPDATE', 'utilisateurs', '9', NULL, NULL, '::1', NULL, '2025-12-25 00:51:33');
INSERT INTO `audit_logs` VALUES ('10', '1', 'CREATE', 'utilisateurs', '14', NULL, NULL, '::1', NULL, '2025-12-25 00:52:18');
INSERT INTO `audit_logs` VALUES ('11', '1', 'UPDATE', 'utilisateurs', '14', NULL, NULL, '::1', NULL, '2025-12-25 00:52:50');
INSERT INTO `audit_logs` VALUES ('12', '14', 'PASSWORD_RESET', 'utilisateurs', '14', NULL, NULL, '::1', NULL, '2025-12-25 17:06:43');
INSERT INTO `audit_logs` VALUES ('13', '1', 'UPDATE', 'utilisateurs', '8', NULL, NULL, '::1', NULL, '2025-12-26 00:12:50');
INSERT INTO `audit_logs` VALUES ('14', '1', 'UPDATE', 'utilisateurs', '8', NULL, NULL, '::1', NULL, '2025-12-26 00:12:56');
INSERT INTO `audit_logs` VALUES ('15', '1', 'UPDATE', 'utilisateurs', '1', NULL, NULL, '::1', NULL, '2025-12-26 13:38:59');
INSERT INTO `audit_logs` VALUES ('16', '1', 'UPDATE', 'utilisateurs', '4', NULL, NULL, '::1', NULL, '2025-12-26 13:39:08');
INSERT INTO `audit_logs` VALUES ('17', '1', 'UPDATE', 'utilisateurs', '4', NULL, NULL, '::1', NULL, '2025-12-26 13:39:12');
INSERT INTO `audit_logs` VALUES ('18', '1', 'PASSWORD_RESET', 'utilisateurs', '1', NULL, NULL, '::1', NULL, '2026-05-20 17:12:03');
INSERT INTO `audit_logs` VALUES ('19', '4', 'PASSWORD_RESET', 'utilisateurs', '4', NULL, NULL, '::1', NULL, '2026-05-20 17:18:57');
INSERT INTO `audit_logs` VALUES ('20', '1', 'PASSWORD_RESET', 'utilisateurs', '1', NULL, NULL, '::1', NULL, '2026-05-22 00:51:18');
INSERT INTO `audit_logs` VALUES ('21', '15', 'REGISTER', 'utilisateurs', '15', NULL, NULL, '::1', NULL, '2026-05-22 13:14:43');
INSERT INTO `audit_logs` VALUES ('22', '1', 'UPDATE', 'utilisateurs', '15', NULL, NULL, '::1', NULL, '2026-05-22 13:15:49');
INSERT INTO `audit_logs` VALUES ('23', '4', 'UPDATE_PROFILE', 'utilisateurs', '4', NULL, NULL, '::1', NULL, '2026-05-24 15:03:09');

--
-- Structure de la table `auth_tokens`
--

DROP TABLE IF EXISTS `auth_tokens`;
CREATE TABLE `auth_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `auth_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
CREATE TABLE `backup_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_type` varchar(50) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `size_mb` decimal(10,2) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_backup_type` (`backup_type`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `backup_history_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `backup_history`
--

INSERT INTO `backup_history` VALUES ('1', 'manual', 'backup_2025-12-22_17-19-06.sql', '0.03', '1', '2025-12-22 18:19:06');

--
-- Structure de la table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
CREATE TABLE `backup_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_id` int(11) DEFAULT NULL,
  `backup_id` int(11) DEFAULT NULL,
  `execution_time` datetime NOT NULL,
  `status` enum('success','failed','partial') NOT NULL,
  `error_message` text,
  `duration_seconds` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `backup_id` (`backup_id`),
  KEY `idx_execution_time` (`execution_time`),
  KEY `idx_status` (`status`),
  CONSTRAINT `backup_logs_ibfk_1` FOREIGN KEY (`schedule_id`) REFERENCES `backup_schedule` (`id`) ON DELETE SET NULL,
  CONSTRAINT `backup_logs_ibfk_2` FOREIGN KEY (`backup_id`) REFERENCES `backup_history` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Structure de la table `backup_schedule`
--

DROP TABLE IF EXISTS `backup_schedule`;
CREATE TABLE `backup_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_name` varchar(100) NOT NULL,
  `backup_type` enum('complete','database','files','incremental') NOT NULL,
  `frequency` enum('daily','weekly','monthly','custom') NOT NULL,
  `execution_time` time NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `retention_days` int(11) DEFAULT '30',
  `last_execution` datetime DEFAULT NULL,
  `next_execution` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_next_execution` (`next_execution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Structure de la table `backup_settings`
--

DROP TABLE IF EXISTS `backup_settings`;
CREATE TABLE `backup_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  `setting_type` enum('string','integer','boolean','json') DEFAULT 'string',
  `description` text,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `backup_settings`
--

INSERT INTO `backup_settings` VALUES ('1', 'backup_directory', '../backups/', 'string', 'Répertoire de stockage des sauvegardes', NULL);
INSERT INTO `backup_settings` VALUES ('2', 'max_storage_mb', '1024', 'integer', 'Espace maximum en MB', NULL);
INSERT INTO `backup_settings` VALUES ('3', 'compression', 'gzip', 'string', 'Méthode de compression (gzip, zip, none)', NULL);
INSERT INTO `backup_settings` VALUES ('4', 'encryption_enabled', 'false', 'boolean', 'Activer le chiffrement des sauvegardes', NULL);
INSERT INTO `backup_settings` VALUES ('5', 'auto_cleanup_enabled', 'true', 'boolean', 'Nettoyage automatique des anciennes sauvegardes', NULL);
INSERT INTO `backup_settings` VALUES ('6', 'retention_days', '30', 'integer', 'Nombre de jours de rétention', NULL);
INSERT INTO `backup_settings` VALUES ('7', 'notify_on_error', 'true', 'boolean', 'Notification en cas d\'erreur', NULL);

--
-- Structure de la table `consultations`
--

DROP TABLE IF EXISTS `consultations`;
CREATE TABLE `consultations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_id` int(11) NOT NULL,
  `docteur_id` int(11) NOT NULL,
  `assistant_id` int(11) DEFAULT NULL,
  `date_consultation` datetime NOT NULL,
  `duree` int(11) DEFAULT '30' COMMENT 'Durée en minutes',
  `type_consultation` enum('premiere','suivi','urgence','controle') COLLATE utf8mb4_unicode_ci DEFAULT 'suivi',
  `motif` text COLLATE utf8mb4_unicode_ci,
  `histoire_maladie` text COLLATE utf8mb4_unicode_ci,
  `examen_clinique` text COLLATE utf8mb4_unicode_ci,
  `examen_complementaire` text COLLATE utf8mb4_unicode_ci,
  `diagnostic` text COLLATE utf8mb4_unicode_ci,
  `diagnostic_detail` text COLLATE utf8mb4_unicode_ci COMMENT 'Structure JSON du diagnostic',
  `traitement` text COLLATE utf8mb4_unicode_ci,
  `ordonnance` text COLLATE utf8mb4_unicode_ci COMMENT 'Structure JSON de l''ordonnance',
  `recommandations` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `statut` enum('planifie','en_cours','termine','annule','reporte') COLLATE utf8mb4_unicode_ci DEFAULT 'planifie',
  `facturee` tinyint(1) DEFAULT '0',
  `urgence` tinyint(1) DEFAULT '0',
  `confidentialite` enum('normal','confidentiel','tres_confidentiel') COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `assistant_id` (`assistant_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_patient` (`patient_id`),
  KEY `idx_docteur` (`docteur_id`),
  KEY `idx_date` (`date_consultation`),
  KEY `idx_statut` (`statut`),
  KEY `idx_type` (`type_consultation`),
  KEY `idx_reference` (`reference`),
  KEY `idx_urgence` (`urgence`),
  KEY `idx_consultations_date` (`date_consultation`),
  KEY `idx_consultations_patient_docteur` (`patient_id`,`docteur_id`),
  KEY `idx_consultations_statut_date` (`statut`,`date_consultation`),
  CONSTRAINT `consultations_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `consultations_ibfk_2` FOREIGN KEY (`docteur_id`) REFERENCES `utilisateurs` (`id`),
  CONSTRAINT `consultations_ibfk_3` FOREIGN KEY (`assistant_id`) REFERENCES `utilisateurs` (`id`),
  CONSTRAINT `consultations_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `consultations`
--

INSERT INTO `consultations` VALUES ('1', 'CONS-202401-0001', '1', '2', '4', '2026-06-15 09:00:00', '30', 'controle', 'Contrôle tension artérielle', '', '', '', 'Hypertension stable sous traitement', NULL, 'Continuer Amlodipine 5mg, surveillance mensuelle', NULL, '', '', 'termine', '0', '0', 'normal', '2025-12-20 00:41:53', '2026-05-24 15:49:39', '4');
INSERT INTO `consultations` VALUES ('2', 'CONS-202401-0002', '2', '2', '4', '2024-01-16 10:30:00', '120', 'urgence', 'Douleurs thoraciques', '', '', '', 'Angor stable, pas d\'urgence', NULL, 'Repos, ECG de contrôle, consultation cardiologue', NULL, '', '', 'termine', '0', '0', 'normal', '2025-12-20 00:41:53', '2026-05-24 16:41:30', '4');
INSERT INTO `consultations` VALUES ('3', 'CONS-202401-0003', '3', '5', NULL, '2024-01-17 14:00:00', '30', 'premiere', 'Éruption cutanée', NULL, NULL, NULL, 'Eczéma atopique', NULL, 'Crème corticoïde, émollients, éviction allergènes', NULL, NULL, NULL, 'termine', '0', '0', 'normal', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '6');
INSERT INTO `consultations` VALUES ('4', 'CONS-202401-0004', '4', '2', '4', '2024-01-18 11:00:00', '30', 'suivi', 'Suivi diabète', '', '', '', 'Diabète équilibré', NULL, 'Continuer Metformine 1000mg, régime contrôlé', NULL, '', '', 'termine', '0', '0', 'normal', '2025-12-20 00:41:53', '2026-05-24 16:43:40', '4');
INSERT INTO `consultations` VALUES ('5', 'CONS-202401-0005', '5', '5', '4', '2024-01-19 15:30:00', '30', '', 'Migraines récurrentes', '', '', '', 'Migraines avec aura', NULL, 'Sumatriptan 50mg si crise, propranolol 40mg/j en prévention', NULL, '', '', 'termine', '0', '0', 'normal', '2025-12-20 00:41:53', '2026-05-24 15:39:19', '6');
INSERT INTO `consultations` VALUES ('6', 'CONS-202401-0006', '6', '7', NULL, '2024-01-20 10:00:00', '30', 'premiere', 'Examen médical général', NULL, NULL, NULL, 'Bon état de santé général', NULL, 'Aucun traitement nécessaire', NULL, NULL, NULL, 'termine', '0', '0', 'normal', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');
INSERT INTO `consultations` VALUES ('7', 'CONS-202401-0007', '7', '7', '4', '2026-06-28 14:30:00', '30', 'suivi', 'Contrôle allergies', '', '', '', 'Allergies saisonnières confirmées', NULL, 'Antihistaminiques, éviction des allergènes', NULL, '', '', 'termine', '0', '0', 'normal', '2025-12-20 00:41:53', '2026-05-24 16:00:11', '3');
INSERT INTO `consultations` VALUES ('10', 'CONS-202605-0001', '6', '2', '4', '2026-05-24 09:00:00', '30', 'suivi', 'maladie', '', '', '', '', NULL, '', NULL, '', '', 'planifie', '0', '0', 'normal', '2026-05-24 16:37:43', '2026-05-24 16:37:43', '4');
INSERT INTO `consultations` VALUES ('11', 'CONS-202605-0002', '5', '2', '4', '2026-06-02 09:00:00', '30', '', 'douleurs', '', '', '', '', NULL, '', NULL, '', '', 'planifie', '0', '0', 'normal', '2026-05-24 16:43:02', '2026-05-24 16:43:02', '4');

--
-- Structure de la table `docteur_specialite`
--

DROP TABLE IF EXISTS `docteur_specialite`;
CREATE TABLE `docteur_specialite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `docteur_id` int(11) NOT NULL,
  `specialite_id` int(11) NOT NULL,
  `principal` tinyint(1) DEFAULT '0',
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_docteur_specialite` (`docteur_id`,`specialite_id`),
  KEY `idx_docteur` (`docteur_id`),
  KEY `idx_specialite` (`specialite_id`),
  KEY `idx_principal` (`principal`),
  CONSTRAINT `docteur_specialite_ibfk_1` FOREIGN KEY (`docteur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `docteur_specialite_ibfk_2` FOREIGN KEY (`specialite_id`) REFERENCES `specialites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `docteur_specialite`
--

INSERT INTO `docteur_specialite` VALUES ('1', '2', '1', '1', NULL, NULL, NULL, '2025-12-20 00:41:53');
INSERT INTO `docteur_specialite` VALUES ('2', '5', '2', '1', NULL, NULL, NULL, '2025-12-20 00:41:53');
INSERT INTO `docteur_specialite` VALUES ('3', '7', '10', '1', NULL, NULL, NULL, '2025-12-20 00:41:53');
INSERT INTO `docteur_specialite` VALUES ('4', '5', '10', '0', NULL, NULL, NULL, '2025-12-20 00:41:53');

--
-- Structure de la table `documents_medicaux`
--

DROP TABLE IF EXISTS `documents_medicaux`;
CREATE TABLE `documents_medicaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `docteur_id` int(11) DEFAULT NULL,
  `consultation_id` int(11) DEFAULT NULL,
  `type` enum('ordonnance','certificat','resultat_analyse','compte_rendu','imagerie','autre') NOT NULL,
  `titre` varchar(200) NOT NULL,
  `description` text,
  `fichier_path` varchar(255) DEFAULT NULL,
  `fichier_nom` varchar(255) DEFAULT NULL,
  `taille` int(11) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `confidentialite` enum('normal','confidentiel','tres_confidentiel') DEFAULT 'normal',
  `valide_jusqu` date DEFAULT NULL,
  `metadata` text,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `consultation_id` (`consultation_id`),
  KEY `idx_patient` (`patient_id`),
  KEY `idx_type` (`type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_created_by` (`created_by`),
  KEY `documents_medicaux_ibfk_4` (`docteur_id`),
  CONSTRAINT `documents_medicaux_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documents_medicaux_ibfk_2` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `documents_medicaux_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`),
  CONSTRAINT `documents_medicaux_ibfk_4` FOREIGN KEY (`docteur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `documents_medicaux`
--

INSERT INTO `documents_medicaux` VALUES ('1', '1', '2', '1', 'compte_rendu', 'Compte rendu consultation cardiologie', 'Consultation de contrôle tension artérielle', 'documents/6949e5288d904_Handwritten-Notes-53-1024x576.png', 'cr_20240115_001.pdf', NULL, NULL, 'normal', NULL, NULL, '2', '2025-12-20 00:41:53', '2025-12-23 01:41:12');
INSERT INTO `documents_medicaux` VALUES ('2', '2', '2', '2', 'ordonnance', 'Ordonnance médicale', 'Médicaments pour douleurs thoraciques', 'documents/6949d4504cef8_base python.png', 'ordo_20240116_001.pdf', NULL, NULL, 'normal', '0000-00-00', NULL, '2', '2025-12-20 00:41:53', '2025-12-23 00:29:47');
INSERT INTO `documents_medicaux` VALUES ('3', '3', '5', '3', 'resultat_analyse', 'Résultats tests allergiques', 'Tests cutanés allergologiques', NULL, 'tests_allergie_001.pdf', NULL, NULL, 'confidentiel', NULL, NULL, '5', '2025-12-20 00:41:53', '2025-12-23 00:45:49');
INSERT INTO `documents_medicaux` VALUES ('4', '5', '5', '5', 'certificat', 'Certificat médical', 'Certificat pour arrêt de travail', NULL, 'certif_20240119_001.pdf', NULL, NULL, 'confidentiel', NULL, NULL, '5', '2025-12-20 00:41:53', '2025-12-23 00:45:49');

--
-- Structure de la table `email_verifications`
--

DROP TABLE IF EXISTS `email_verifications`;
CREATE TABLE `email_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `verified_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `email_verifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
CREATE TABLE `equipment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `categorie` varchar(100) NOT NULL,
  `marque` varchar(100) DEFAULT NULL,
  `modele` varchar(100) DEFAULT NULL,
  `numero_serie` varchar(100) DEFAULT NULL,
  `date_acquisition` date DEFAULT NULL,
  `valeur` decimal(10,2) DEFAULT '0.00',
  `localisation` varchar(100) DEFAULT NULL,
  `statut` enum('actif','maintenance','hors_service','reserve','supprime') DEFAULT 'actif',
  `notes` text,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_serie` (`numero_serie`),
  KEY `created_by` (`created_by`),
  KEY `idx_equipment_statut` (`statut`),
  KEY `idx_equipment_categorie` (`categorie`),
  KEY `idx_equipment_localisation` (`localisation`),
  CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `equipment`
--

INSERT INTO `equipment` VALUES ('1', 'Admin', 'diagnostic', 'ddd', '43d', '3333', '2026-01-04', '100.00', 'bujumbura', 'supprime', 'operation', '14', '2026-01-04 18:03:41', '2026-01-04 18:17:04');

--
-- Structure de la table `equipment_history`
--

DROP TABLE IF EXISTS `equipment_history`;
CREATE TABLE `equipment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `equipment_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `details` text,
  `performed_by` int(11) DEFAULT NULL,
  `performed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `performed_by` (`performed_by`),
  KEY `idx_equipment_history_date` (`performed_at`),
  CONSTRAINT `equipment_history_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`) ON DELETE CASCADE,
  CONSTRAINT `equipment_history_ibfk_2` FOREIGN KEY (`performed_by`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `equipment_history`
--

INSERT INTO `equipment_history` VALUES ('1', '1', 'Ajout', 'Équipement ajouté: Admin (diagnostic)', '14', '2026-01-04 18:03:41');
INSERT INTO `equipment_history` VALUES ('2', '1', 'Suppression', 'Équipement supprimé: Admin (3333)', '14', '2026-01-04 18:11:11');
INSERT INTO `equipment_history` VALUES ('3', '1', 'Suppression', 'Équipement supprimé: Admin (3333)', '14', '2026-01-04 18:12:13');
INSERT INTO `equipment_history` VALUES ('4', '1', 'Suppression', 'Équipement supprimé: Admin (3333)', '14', '2026-01-04 18:13:14');
INSERT INTO `equipment_history` VALUES ('5', '1', 'Suppression', 'Équipement supprimé: Admin (3333)', '14', '2026-01-04 18:14:15');
INSERT INTO `equipment_history` VALUES ('6', '1', 'Suppression', 'Équipement supprimé: Admin (3333)', '14', '2026-01-04 18:15:16');
INSERT INTO `equipment_history` VALUES ('7', '1', 'Suppression', 'Équipement supprimé: Admin (3333)', '14', '2026-01-04 18:16:17');
INSERT INTO `equipment_history` VALUES ('8', '1', 'Suppression', 'Équipement supprimé: Admin (3333)', '14', '2026-01-04 18:17:04');

--
-- Structure de la table `log_archive`
--

DROP TABLE IF EXISTS `log_archive`;
CREATE TABLE `log_archive` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `old_values` text COLLATE utf8mb4_unicode_ci,
  `new_values` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `message` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `archived_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_archived_at` (`archived_at`),
  KEY `idx_action` (`action`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `login_logs`
--

DROP TABLE IF EXISTS `login_logs`;
CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `login_time` datetime NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `success` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_user_time` (`user_id`,`login_time`),
  KEY `idx_login_time` (`login_time`),
  CONSTRAINT `login_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `login_logs`
--

INSERT INTO `login_logs` VALUES ('1', '1', '2025-12-21 23:09:28', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('2', '1', '2025-12-22 15:58:52', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('3', '1', '2025-12-22 16:41:50', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('4', '1', '2025-12-22 16:42:32', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('5', '2', '2025-12-22 16:42:43', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('6', '1', '2025-12-22 16:45:37', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('7', '1', '2025-12-22 16:46:54', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('8', '2', '2025-12-23 00:07:49', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('9', '1', '2025-12-23 00:35:41', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('10', '2', '2025-12-23 11:47:42', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('11', '1', '2025-12-23 11:52:12', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('12', '6', '2025-12-23 11:55:06', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('13', '1', '2025-12-23 23:39:54', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('14', '1', '2025-12-24 10:30:08', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('15', '1', '2025-12-24 14:16:06', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('16', '1', '2025-12-24 14:18:06', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('17', '2', '2025-12-24 20:53:01', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('18', '1', '2025-12-24 20:54:25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('19', '8', '2025-12-24 20:55:55', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('20', '6', '2025-12-24 20:58:03', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('21', '1', '2025-12-25 00:11:31', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('22', '10', '2025-12-25 00:20:29', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('23', '10', '2025-12-25 00:53:48', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('24', '10', '2025-12-25 00:56:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('25', '14', '2025-12-25 17:07:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('26', '2', '2025-12-25 17:41:15', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('27', '1', '2025-12-25 23:32:55', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('28', '1', '2025-12-26 12:05:52', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('29', '14', '2025-12-26 13:02:48', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('30', '2', '2025-12-26 13:10:50', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('31', '14', '2025-12-26 23:31:27', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('32', '2', '2025-12-26 23:33:22', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('33', '1', '2025-12-26 23:35:16', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('34', '6', '2025-12-27 20:51:10', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('35', '2', '2025-12-27 20:51:22', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('36', '1', '2025-12-27 20:51:38', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('37', '1', '2026-01-01 14:59:52', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('38', '1', '2026-01-04 17:08:01', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('39', '1', '2026-01-04 17:10:56', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('40', '14', '2026-01-04 17:14:10', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('41', '1', '2026-05-20 17:12:19', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('42', '4', '2026-05-20 17:19:06', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('43', '4', '2026-05-20 17:19:53', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('44', '1', '2026-05-22 00:51:36', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('45', '1', '2026-05-22 13:04:35', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('46', '1', '2026-05-22 13:07:28', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('47', '1', '2026-05-22 13:10:56', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('48', '1', '2026-05-22 13:11:24', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('49', '1', '2026-05-22 13:15:18', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('50', '1', '2026-05-23 00:18:18', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('51', '1', '2026-05-23 00:23:20', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('52', '1', '2026-05-23 11:48:59', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('53', '1', '2026-05-24 14:30:50', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('54', '4', '2026-05-24 14:32:01', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('55', '1', '2026-05-24 19:42:16', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');
INSERT INTO `login_logs` VALUES ('56', '1', '2026-05-25 12:53:38', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '1');

--
-- Structure de la table `medicament_distribution`
--

DROP TABLE IF EXISTS `medicament_distribution`;
CREATE TABLE `medicament_distribution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medicament_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `consultation_id` int(11) DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `date_distribution` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `distributed_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medicament_id` (`medicament_id`),
  KEY `patient_id` (`patient_id`),
  KEY `consultation_id` (`consultation_id`),
  KEY `distributed_by` (`distributed_by`),
  KEY `idx_medicament_distribution_date` (`date_distribution`),
  CONSTRAINT `medicament_distribution_ibfk_1` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `medicament_distribution_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `medicament_distribution_ibfk_3` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `medicament_distribution_ibfk_4` FOREIGN KEY (`distributed_by`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Structure de la table `medicament_stock_log`
--

DROP TABLE IF EXISTS `medicament_stock_log`;
CREATE TABLE `medicament_stock_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medicament_id` int(11) NOT NULL,
  `operation` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantite` int(11) NOT NULL,
  `ancien_stock` int(11) NOT NULL,
  `nouveau_stock` int(11) NOT NULL,
  `raison` text COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `medicament_id` (`medicament_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `medicament_stock_log_ibfk_1` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `medicament_stock_log_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `medicaments`
--

DROP TABLE IF EXISTS `medicaments`;
CREATE TABLE `medicaments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_cip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nom_commercial` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom_generique` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `laboratoire` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forme` enum('comprime','gelule','sirop','injectable','pommade','creme','suppositoire','collyre','spray','poudre','autre') COLLATE utf8mb4_unicode_ci NOT NULL,
  `dosage` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `classe_therapeutique` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indications` text COLLATE utf8mb4_unicode_ci,
  `contre_indications` text COLLATE utf8mb4_unicode_ci,
  `effets_secondaires` text COLLATE utf8mb4_unicode_ci,
  `posologie` text COLLATE utf8mb4_unicode_ci,
  `precautions` text COLLATE utf8mb4_unicode_ci,
  `interactions` text COLLATE utf8mb4_unicode_ci,
  `conditionnement` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock_actuel` int(11) NOT NULL DEFAULT '0',
  `stock_minimum` int(11) NOT NULL DEFAULT '10',
  `prix_unitaire` decimal(10,2) NOT NULL DEFAULT '0.00',
  `remboursement` decimal(5,2) DEFAULT '0.00',
  `statut` enum('actif','inactif','rupture','retire') COLLATE utf8mb4_unicode_ci DEFAULT 'actif',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_cip` (`code_cip`),
  KEY `idx_nom_commercial` (`nom_commercial`(191)),
  KEY `idx_statut` (`statut`),
  KEY `idx_stock` (`stock_actuel`),
  KEY `idx_classe` (`classe_therapeutique`),
  KEY `idx_laboratoire` (`laboratoire`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `medicaments`
--

INSERT INTO `medicaments` VALUES ('1', '3400933596033', 'Doliprane', 'Paracétamol', 'Sanofi', 'comprime', '1000mg', 'Antalgique', 'Douleurs et fièvre', NULL, NULL, NULL, NULL, NULL, NULL, '150', '20', '2.50', '65.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 18:15:40');
INSERT INTO `medicaments` VALUES ('2', '3400931254876', 'Ibuprofène', 'Ibuprofène', 'Bayer', 'comprime', '400mg', 'Anti-inflammatoire', 'Douleurs et inflammations', NULL, NULL, NULL, NULL, NULL, NULL, '80', '15', '3.20', '35.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 18:15:40');
INSERT INTO `medicaments` VALUES ('3', '3400934875129', 'Amoxicilline', 'Amoxicilline', 'GSK', 'gelule', '500mg', 'Antibiotique', 'Infections bactériennes', '', '', '', '', '', '', '46', '25', '5.80', '100.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 19:32:50');
INSERT INTO `medicaments` VALUES ('4', '3400936548721', 'Ventoline', 'Salbutamol', 'GSK', 'spray', '100mcg/dose', 'Bronchodilatateur', 'Asthme, bronchite', NULL, NULL, NULL, NULL, NULL, NULL, '120', '30', '12.50', '65.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 18:15:40');
INSERT INTO `medicaments` VALUES ('5', '3400932154873', 'Levothyrox', 'Lévothyroxine', 'Merck', 'comprime', '75mcg', 'Hormone thyroïdienne', 'Hypothyroïdie', NULL, NULL, NULL, NULL, NULL, NULL, '95', '40', '4.30', '100.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 18:15:40');
INSERT INTO `medicaments` VALUES ('6', '3400936541234', 'Atorvastatine', 'Atorvastatine', 'Pfizer', 'comprime', '20mg', 'Hypolipémiant', 'Cholestérol élevé', NULL, NULL, NULL, NULL, NULL, NULL, '60', '20', '6.75', '65.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 18:15:40');
INSERT INTO `medicaments` VALUES ('7', '3400939874561', 'Lantus', 'Insuline glargine', 'Sanofi', 'injectable', '100UI/ml', 'Antidiabétique', 'Diabète type 1 et 2', NULL, NULL, NULL, NULL, NULL, NULL, '35', '15', '45.00', '100.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 18:15:40');
INSERT INTO `medicaments` VALUES ('8', '3400933216547', 'Xanax', 'Alprazolam', 'Pfizer', 'comprime', '0.25mg', 'Anxiolytique', 'Anxiété, crises de panique', NULL, NULL, NULL, NULL, NULL, NULL, '25', '10', '8.90', '65.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 18:15:40');
INSERT INTO `medicaments` VALUES ('9', '3400936547890', 'Zyrtec', 'Cétirizine', 'UCB', 'comprime', '10mg', 'Antihistaminique', 'Allergies', NULL, NULL, NULL, NULL, NULL, NULL, '110', '25', '3.45', '35.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 18:15:40');
INSERT INTO `medicaments` VALUES ('10', '3400931234567', 'Lasilix', 'Furosémide', 'Sanofi', 'comprime', '40mg', 'Diurétique', 'Hypertension, œdèmes', NULL, NULL, NULL, NULL, NULL, NULL, '70', '20', '2.80', '100.00', 'actif', '2025-12-22 18:15:40', '2025-12-22 18:15:40');

--
-- Structure de la table `mouvements_stock`
--

DROP TABLE IF EXISTS `mouvements_stock`;
CREATE TABLE `mouvements_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medicament_id` int(11) NOT NULL,
  `type_mouvement` enum('entree','sortie','ajustement','inventaire') NOT NULL,
  `quantite` int(11) NOT NULL,
  `quantite_avant` int(11) NOT NULL,
  `quantite_apres` int(11) NOT NULL,
  `motif` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_medicament` (`medicament_id`),
  KEY `idx_date` (`created_at`),
  CONSTRAINT `fk_mouvement_medicament` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `titre` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `lien` varchar(255) DEFAULT NULL,
  `lu` tinyint(1) DEFAULT '0',
  `important` tinyint(1) DEFAULT '0',
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sender_id` int(11) DEFAULT NULL,
  `role_target` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_lu` (`lu`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_type` (`type`),
  KEY `idx_important` (`important`),
  KEY `sender_id` (`sender_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `notifications`
--

INSERT INTO `notifications` VALUES ('1', '2', 'rdv', 'Nouveau rendez-vous', 'Vous avez un nouveau rendez-vous avec M. Durand demain à 9h', '/docteur/rendezvous.php', '1', '0', NULL, '2025-12-20 00:41:53', NULL, NULL);
INSERT INTO `notifications` VALUES ('2', '3', 'patient', 'Nouveau patient enregistré', 'Un nouveau patient a été enregistré : M. Martin', '/secretaire/patients.php', '0', '0', NULL, '2025-12-20 00:41:53', NULL, NULL);
INSERT INTO `notifications` VALUES ('3', '5', 'consultation', 'Consultation à venir', 'Consultation avec Mme Petit dans 2 heures', '/docteur/consultations.php', '0', '1', NULL, '2025-12-20 00:41:53', NULL, NULL);
INSERT INTO `notifications` VALUES ('4', '1', 'system', 'Maintenance planifiée', 'Maintenance système prévue ce soir à 22h', '/admin/gestion.php', '1', '1', NULL, '2025-12-20 00:41:53', NULL, NULL);
INSERT INTO `notifications` VALUES ('5', '2', 'attente', 'Patient appelé', 'Patient gg dd est prêt pour consultation.', 'consultations.php?action=add&patient_id=8', '0', '0', NULL, '2026-05-24 16:14:42', NULL, NULL);
INSERT INTO `notifications` VALUES ('6', '2', 'attente', 'Patient appelé', 'Patient gg dd est prêt pour consultation.', 'consultations.php?action=add&patient_id=8', '0', '0', NULL, '2026-05-24 16:22:44', NULL, NULL);

--
-- Structure de la table `parametres_systeme`
--

DROP TABLE IF EXISTS `parametres_systeme`;
CREATE TABLE `parametres_systeme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cle` varchar(100) NOT NULL,
  `valeur` text,
  `type` varchar(50) DEFAULT 'texte',
  `categorie` varchar(50) DEFAULT 'general',
  `description` text,
  `modifiable` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cle` (`cle`),
  KEY `idx_cle` (`cle`),
  KEY `idx_categorie` (`categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `parametres_systeme`
--

INSERT INTO `parametres_systeme` VALUES ('1', 'app_nom', 'Gestion Médicale', 'texte', 'general', 'Nom de l\'application', '1', '2025-12-20 00:41:53', '2025-12-22 16:02:37');
INSERT INTO `parametres_systeme` VALUES ('2', 'app_version', '2.0.0', 'texte', 'general', 'Version de l\'application', '1', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `parametres_systeme` VALUES ('3', 'app_timezone', 'afrique', 'texte', 'general', 'Fuseau horaire', '1', '2025-12-20 00:41:53', '2025-12-22 16:02:06');
INSERT INTO `parametres_systeme` VALUES ('4', 'session_timeout', '3600', 'nombre', 'securite', 'Timeout session en secondes', '1', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `parametres_systeme` VALUES ('5', 'password_min_length', '8', 'nombre', 'securite', 'Longueur minimale mot de passe', '1', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `parametres_systeme` VALUES ('6', 'consultation_duree_defaut', '30', 'nombre', 'consultation', 'Durée par défaut des consultations', '1', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `parametres_systeme` VALUES ('7', 'rdv_rappel_heures', '24', 'nombre', 'rendezvous', 'Heures avant rappel RDV', '1', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `parametres_systeme` VALUES ('8', 'email_notification', '1', 'booleen', 'notification', 'Activer les notifications email', '1', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `parametres_systeme` VALUES ('9', 'logo_url', '/assets/images/logo.png', 'texte', 'interface', 'URL du logo', '1', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `parametres_systeme` VALUES ('10', 'theme_couleur', '#44e60a', 'couleur', 'interface', 'Couleur principale du thème', '1', '2025-12-20 00:41:53', '2025-12-21 23:42:14');

--
-- Structure de la table `pathologies`
--

DROP TABLE IF EXISTS `pathologies`;
CREATE TABLE `pathologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_cim` varchar(20) DEFAULT NULL,
  `nom` varchar(200) NOT NULL,
  `specialite_id` int(11) DEFAULT NULL,
  `description` text,
  `symptomes` text,
  `causes` text,
  `traitement` text,
  `prevention` text,
  `gravite` enum('faible','moderee','grave','tres_grave') DEFAULT 'moderee',
  `contagieux` tinyint(1) DEFAULT '0',
  `chronique` tinyint(1) DEFAULT '0',
  `date_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_nom` (`nom`(191)),
  KEY `idx_code_cim` (`code_cim`),
  KEY `idx_specialite` (`specialite_id`),
  KEY `idx_gravite` (`gravite`),
  CONSTRAINT `pathologies_ibfk_1` FOREIGN KEY (`specialite_id`) REFERENCES `specialites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `pathologies`
--

INSERT INTO `pathologies` VALUES ('1', 'I10', 'Hypertension artérielle', '1', 'Pression artérielle élevée de façon chronique', 'Maux de tête, vertiges, saignements de nez', NULL, NULL, NULL, 'moderee', '0', '0', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `pathologies` VALUES ('2', 'L20', 'Eczéma atopique', '2', 'Maladie inflammatoire chronique de la peau', 'Démangeaisons, rougeurs, sécheresse cutanée', NULL, NULL, NULL, '', '0', '0', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `pathologies` VALUES ('3', 'G43', 'Migraine', '3', 'Maladie caractérisée par des maux de tête sévères', 'Céphalées, nausées, sensibilité à la lumière', NULL, NULL, NULL, 'moderee', '0', '0', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `pathologies` VALUES ('4', 'J45', 'Asthme', '4', 'Maladie inflammatoire des bronches', 'Essoufflement, sifflements, toux', NULL, NULL, NULL, 'grave', '0', '0', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `pathologies` VALUES ('5', 'E11', 'Diabète de type 2', '1', 'Trouble métabolique caractérisé par une hyperglycémie', 'Soif intense, fatigue, besoin fréquent d\'uriner', NULL, NULL, NULL, 'grave', '0', '0', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `pathologies` VALUES ('6', 'F41', 'Trouble anxieux généralisé', '7', 'Anxiété excessive et persistante', 'Inquiétude constante, tension musculaire, fatigue', NULL, NULL, NULL, 'moderee', '0', '0', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `pathologies` VALUES ('7', 'M17', 'Gonarthrose', '8', 'Arthrose du genou', 'Douleurs articulaires, raideur, difficulté à marcher', NULL, NULL, NULL, 'moderee', '0', '0', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `pathologies` VALUES ('8', 'H10', 'Conjonctivite', '9', 'Inflammation de la conjonctive oculaire', 'Rougeur, démangeaisons, écoulement oculaire', NULL, NULL, NULL, '', '0', '0', '2025-12-20 00:41:53', '2025-12-20 00:41:53');

--
-- Structure de la table `patient_pathologie`
--

DROP TABLE IF EXISTS `patient_pathologie`;
CREATE TABLE `patient_pathologie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `pathologie_id` int(11) NOT NULL,
  `date_diagnostic` date NOT NULL,
  `diagnostic_par` int(11) DEFAULT NULL,
  `gravite` enum('legere','moderee','grave') DEFAULT 'moderee',
  `stade` varchar(50) DEFAULT NULL,
  `traitement_actuel` text,
  `evolution` text,
  `notes` text,
  `statut` enum('active','guerie','chronique','en_suivi') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_patient_pathologie` (`patient_id`,`pathologie_id`),
  KEY `diagnostic_par` (`diagnostic_par`),
  KEY `idx_patient` (`patient_id`),
  KEY `idx_pathologie` (`pathologie_id`),
  KEY `idx_statut` (`statut`),
  KEY `idx_date_diagnostic` (`date_diagnostic`),
  CONSTRAINT `patient_pathologie_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_pathologie_ibfk_2` FOREIGN KEY (`pathologie_id`) REFERENCES `pathologies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_pathologie_ibfk_3` FOREIGN KEY (`diagnostic_par`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `patient_pathologie`
--

INSERT INTO `patient_pathologie` VALUES ('1', '1', '1', '2023-05-10', '2', 'moderee', NULL, NULL, NULL, NULL, 'chronique', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `patient_pathologie` VALUES ('2', '2', '5', '2022-11-15', '2', 'grave', NULL, NULL, NULL, NULL, 'en_suivi', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `patient_pathologie` VALUES ('3', '3', '2', '2023-08-22', '5', 'legere', NULL, NULL, NULL, NULL, 'active', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `patient_pathologie` VALUES ('4', '3', '4', '2015-03-10', NULL, 'moderee', NULL, NULL, NULL, NULL, 'chronique', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `patient_pathologie` VALUES ('5', '5', '3', '2020-06-30', '5', 'moderee', NULL, NULL, NULL, NULL, 'chronique', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `patient_pathologie` VALUES ('6', '4', '1', '2021-09-05', '2', 'legere', NULL, NULL, NULL, NULL, 'active', '2025-12-20 00:41:53', '2025-12-20 00:41:53');
INSERT INTO `patient_pathologie` VALUES ('7', '7', '8', '2023-04-15', '7', 'legere', NULL, NULL, NULL, NULL, 'guerie', '2025-12-20 00:41:53', '2025-12-20 00:41:53');

--
-- Structure de la table `patients`
--

DROP TABLE IF EXISTS `patients`;
CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_patient` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_naissance` date NOT NULL,
  `sexe` enum('M','F') COLLATE utf8mb4_unicode_ci NOT NULL,
  `lieu_naissance` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adresse` text COLLATE utf8mb4_unicode_ci,
  `ville` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_postal` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pays` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'France',
  `telephone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone_urgence` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profession` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `situation_familiale` enum('celibataire','marie','divorce','veuf') COLLATE utf8mb4_unicode_ci DEFAULT 'celibataire',
  `nombre_enfants` int(11) DEFAULT '0',
  `groupe_sanguin` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rhésus` enum('+','-') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `poids` decimal(5,2) DEFAULT NULL,
  `taille` decimal(5,2) DEFAULT NULL,
  `imc` decimal(5,2) DEFAULT NULL,
  `antecedents_familiaux` text COLLATE utf8mb4_unicode_ci,
  `antecedents_personnels` text COLLATE utf8mb4_unicode_ci,
  `allergies` text COLLATE utf8mb4_unicode_ci,
  `medicaments_habituels` text COLLATE utf8mb4_unicode_ci,
  `habitudes` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `statut` enum('actif','archive','decede') COLLATE utf8mb4_unicode_ci DEFAULT 'actif',
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_patient` (`code_patient`),
  KEY `idx_nom_prenom` (`nom`,`prenom`),
  KEY `idx_code_patient` (`code_patient`),
  KEY `idx_date_naissance` (`date_naissance`),
  KEY `idx_statut` (`statut`),
  KEY `idx_ville` (`ville`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_patients_date_naissance` (`date_naissance`),
  KEY `idx_patients_ville` (`ville`),
  KEY `idx_patients_sexe` (`sexe`),
  KEY `idx_patients_statut` (`statut`),
  CONSTRAINT `patients_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `patients`
--

INSERT INTO `patients` VALUES ('1', 'PAT-202401-0001', 'Durand', 'Marie', '1985-06-15', 'F', NULL, '123 Rue de Paris', 'Paris', '75001', 'France', '+33612345678', NULL, 'marie.durand@email.com', NULL, 'celibataire', '0', 'A+', NULL, NULL, NULL, NULL, NULL, 'Hypertension familiale, Cholestérol', 'Pénicilline, Arachides', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');
INSERT INTO `patients` VALUES ('2', 'PAT-202401-0002', 'Leroy', 'Paul', '1978-03-22', 'M', NULL, '456 Avenue Victor Hugo', 'Lyon', '69002', 'France', '+33687654321', NULL, 'paul.leroy@email.com', NULL, 'celibataire', '0', 'O+', NULL, NULL, NULL, NULL, NULL, 'Diabète type 2, Cholestérol', 'Aucune', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');
INSERT INTO `patients` VALUES ('3', 'PAT-202401-0003', 'Petit', 'Julie', '1992-11-30', 'F', NULL, '789 Boulevard Saint-Germain', 'Marseille', '13001', 'France', '+33611223344', NULL, 'julie.petit@email.com', NULL, 'celibataire', '0', 'B+', NULL, NULL, NULL, NULL, NULL, 'Asthme depuis l\'enfance, Eczéma', 'Acariens, Pollen, Poils de chat', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '8');
INSERT INTO `patients` VALUES ('4', 'PAT-202401-0004', 'Moreau', 'Thomas', '1965-08-12', 'M', NULL, '321 Rue de la République', 'Toulouse', '31000', 'France', '+33699887766', NULL, 'thomas.moreau@email.com', NULL, 'celibataire', '0', 'AB+', NULL, NULL, NULL, NULL, NULL, 'Opération genou 2018, Hypertension', 'Iode, Crustacés', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');
INSERT INTO `patients` VALUES ('5', 'PAT-202401-0005', 'Simon', 'Claire', '1972-12-05', 'F', NULL, '654 Rue du Commerce', 'Lille', '59000', 'France', '+33655443322', NULL, 'claire.simon@email.com', NULL, 'celibataire', '0', 'A-', NULL, NULL, NULL, NULL, NULL, 'Migraines chroniques, Dépression', 'Aspirine, Ibuprofène', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '8');
INSERT INTO `patients` VALUES ('6', 'PAT-202401-0006', 'Dubois', 'Marc', '1988-07-19', 'M', NULL, '987 Avenue des Champs-Élysées', 'Paris', '75008', 'France', '+33666778899', NULL, 'marc.dubois@email.com', NULL, 'celibataire', '0', 'O-', NULL, NULL, NULL, NULL, NULL, 'Sportif, Aucun antécédent', 'Aucune', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');
INSERT INTO `patients` VALUES ('7', 'PAT-202401-0007', 'Laurent', 'Sophie', '1995-04-25', 'F', NULL, '159 Rue de la Liberté', 'Bordeaux', '33000', 'France', '+33622334455', NULL, 'sophie.laurent@email.com', NULL, 'celibataire', '0', 'B-', NULL, NULL, NULL, NULL, NULL, 'Allergies saisonnières', 'Pollens, Moisissures', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '8');
INSERT INTO `patients` VALUES ('8', 'PAT-202605-0001', 'dd', 'gg', '2026-05-26', 'M', NULL, 'bbbbbbbbbbbbb', 'vvvvvvvvvvvvvvv', '1111111111', 'France', '+33123456792', NULL, 'chalij68@gmail.com', NULL, 'celibataire', '0', 'O-', NULL, NULL, NULL, NULL, NULL, 'dddddddddddddddd', 'ddddddddd', NULL, NULL, NULL, 'actif', '2026-05-24 16:03:24', '2026-05-24 16:03:24', '4');

--
-- Structure de la table `prescription_details`
--

DROP TABLE IF EXISTS `prescription_details`;
CREATE TABLE `prescription_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prescription_id` int(11) NOT NULL,
  `medicament_id` int(11) DEFAULT NULL,
  `nom_medicament` varchar(200) NOT NULL,
  `dosage` varchar(50) NOT NULL,
  `forme` varchar(50) DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `posologie` text NOT NULL,
  `duree` varchar(50) DEFAULT NULL,
  `instructions` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_prescription` (`prescription_id`),
  KEY `idx_medicament` (`medicament_id`),
  CONSTRAINT `prescription_details_ibfk_1` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `prescription_details`
--

INSERT INTO `prescription_details` VALUES ('13', '2147483647', '0', 'Amlodipine', '5 mg', 'comprimé', '0', 'Antihypertenseur', '65%', NULL, '2025-12-23 00:43:31', '2025-12-23 00:43:31');
INSERT INTO `prescription_details` VALUES ('14', '2147483647', '0', 'Acide acétylsalicylique', '160 mg', 'comprimé gastro-résistant', '0', 'Antiagrégant plaquettaire', '65%', NULL, '2025-12-23 00:43:31', '2025-12-23 00:43:31');
INSERT INTO `prescription_details` VALUES ('15', '2147483647', '0', 'Amlodipine', '5 mg', 'comprimé', '0', 'Antihypertenseur', '65%', NULL, '2025-12-23 00:43:53', '2025-12-23 00:43:53');
INSERT INTO `prescription_details` VALUES ('16', '2147483647', '0', 'Acide acétylsalicylique', '160 mg', 'comprimé gastro-résistant', '0', 'Antiagrégant plaquettaire', '65%', NULL, '2025-12-23 00:43:53', '2025-12-23 00:43:53');
INSERT INTO `prescription_details` VALUES ('17', '2147483647', '0', 'Azathioprine', '50 mg', 'comprimé', '0', 'Immunosuppresseur', '100%', NULL, '2025-12-23 00:43:53', '2025-12-23 00:43:53');
INSERT INTO `prescription_details` VALUES ('18', '2147483647', '0', 'Paracétamol', '500 mg', 'comprimé', '0', 'Antalgique', '65%', NULL, '2025-12-23 00:43:53', '2025-12-23 00:43:53');
INSERT INTO `prescription_details` VALUES ('19', '2147483647', '0', 'Atorvastatine', '10 mg', 'comprimé', '0', 'Hypolipémiant', '65%', NULL, '2025-12-23 00:43:53', '2025-12-23 00:43:53');

--
-- Structure de la table `prescriptions`
--

DROP TABLE IF EXISTS `prescriptions`;
CREATE TABLE `prescriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultation_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `docteur_id` int(11) NOT NULL,
  `reference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_prescription` date NOT NULL,
  `medicaments` text COLLATE utf8mb4_unicode_ci COMMENT 'Structure JSON des médicaments',
  `posologie` text COLLATE utf8mb4_unicode_ci,
  `duree_traitement` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `renouvelable` tinyint(1) DEFAULT '0',
  `nombre_renouvellements` int(11) DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `statut` enum('active','terminee','annulee') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `idx_patient` (`patient_id`),
  KEY `idx_docteur` (`docteur_id`),
  KEY `idx_date` (`date_prescription`),
  KEY `idx_statut` (`statut`),
  KEY `idx_reference` (`reference`),
  KEY `idx_consultation` (`consultation_id`),
  KEY `idx_prescriptions_patient_date` (`patient_id`,`date_prescription`),
  CONSTRAINT `prescriptions_ibfk_1` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prescriptions_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prescriptions_ibfk_3` FOREIGN KEY (`docteur_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `prescriptions`
--

INSERT INTO `prescriptions` VALUES ('1', '1', '1', '2', 'PRES-202401-0001', '2024-01-15', '[{\"nom\":\"Amlodipine\",\"dosage\":\"5mg\",\"forme\":\"comprime\",\"quantite\":30,\"posologie\":\"1 comprimé par jour\",\"repas\":\"indifferent\"}]', 'Prendre 1 comprimé par jour, de préférence le matin', '30 jours', '0', '0', NULL, 'active', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '0');
INSERT INTO `prescriptions` VALUES ('2', '3', '3', '5', 'PRES-202401-0002', '2024-01-17', '[{\"nom\":\"Corticoide topique\",\"dosage\":\"0.1%\",\"forme\":\"creme\",\"quantite\":1,\"posologie\":\"appliquer 2 fois par jour\",\"zone\":\"zones atteintes\"},{\"nom\":\"Emollient\",\"dosage\":\"\",\"forme\":\"creme\",\"quantite\":1,\"posologie\":\"appliquer quotidiennement\",\"zone\":\"peau seche\"}]', 'Appliquer la crème corticoïde sur les lésions 2 fois par jour. Utiliser l\'émollient quotidiennement sur toute la peau.', '15 jours', '0', '0', NULL, 'active', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '0');
INSERT INTO `prescriptions` VALUES ('3', '5', '5', '5', 'PRES-202401-0003', '2024-01-19', '[{\"nom\":\"Sumatriptan\",\"dosage\":\"50mg\",\"forme\":\"comprime\",\"quantite\":6,\"posologie\":\"1 comprimé au début de la crise\",\"max\":\"2 comprimés par 24h\"},{\"nom\":\"Propranolol\",\"dosage\":\"40mg\",\"forme\":\"comprime\",\"quantite\":30,\"posologie\":\"1 comprimé par jour\",\"repas\":\"pendant les repas\"}]', 'Sumatriptan : prendre au début de la crise (max 2/24h). Propranolol : 1 comprimé par jour pendant les repas.', '30 jours', '0', '0', NULL, 'active', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '0');
INSERT INTO `prescriptions` VALUES ('4', '1', '1', '2', 'PRES-202605-0001', '2026-05-24', 'amoxiline 500mg', NULL, '1 mois', '1', '0', '', 'active', '2026-05-24 15:49:59', '2026-05-24 15:49:59', '4');

--
-- Structure de la table `rendez_vous`
--

DROP TABLE IF EXISTS `rendez_vous`;
CREATE TABLE `rendez_vous` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `docteur_id` int(11) NOT NULL,
  `date_rdv` datetime NOT NULL,
  `duree` int(11) DEFAULT '30' COMMENT 'Durée en minutes',
  `type_rdv` enum('consultation','controle','urgence','autre') DEFAULT 'consultation',
  `motif` text,
  `notes` text,
  `statut` enum('confirme','annule','reporte','present','absent') DEFAULT 'confirme',
  `rappel_envoye` tinyint(1) DEFAULT '0',
  `rappel_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `created_by` (`created_by`),
  KEY `idx_patient` (`patient_id`),
  KEY `idx_docteur` (`docteur_id`),
  KEY `idx_date` (`date_rdv`),
  KEY `idx_statut` (`statut`),
  KEY `idx_reference` (`reference`),
  KEY `idx_rappel` (`rappel_envoye`,`rappel_date`),
  KEY `idx_rdv_date` (`date_rdv`),
  CONSTRAINT `rendez_vous_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rendez_vous_ibfk_2` FOREIGN KEY (`docteur_id`) REFERENCES `utilisateurs` (`id`),
  CONSTRAINT `rendez_vous_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `rendez_vous`
--

INSERT INTO `rendez_vous` VALUES ('1', 'RDV-202402-0001', '1', '2', '2024-02-01 09:00:00', '30', 'consultation', 'Contrôle tension mensuel', NULL, 'confirme', '0', NULL, '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');
INSERT INTO `rendez_vous` VALUES ('2', 'RDV-202402-0002', '2', '2', '2024-02-02 10:30:00', '30', 'consultation', 'ECG de contrôle', NULL, 'confirme', '0', NULL, '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');
INSERT INTO `rendez_vous` VALUES ('3', 'RDV-202402-0003', '3', '5', '2024-02-03 14:00:00', '30', 'consultation', 'Suivi eczéma', NULL, 'confirme', '0', NULL, '2025-12-20 00:41:53', '2025-12-20 00:41:53', '8');
INSERT INTO `rendez_vous` VALUES ('4', 'RDV-202402-0004', '4', '2', '2024-02-04 11:00:00', '30', 'consultation', 'Contrôle glycémie', NULL, 'confirme', '0', NULL, '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');
INSERT INTO `rendez_vous` VALUES ('5', 'RDV-202402-0005', '5', '5', '2024-02-05 15:30:00', '30', 'consultation', 'Évaluation traitement migraine', NULL, 'confirme', '0', NULL, '2025-12-20 00:41:53', '2025-12-20 00:41:53', '8');
INSERT INTO `rendez_vous` VALUES ('6', 'RDV-202402-0006', '6', '7', '2024-02-06 10:00:00', '30', 'consultation', 'Examen de routine', NULL, 'confirme', '0', NULL, '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');
INSERT INTO `rendez_vous` VALUES ('7', 'RDV-202402-0007', '7', '7', '2024-02-07 14:30:00', '30', 'consultation', 'Suivi allergies', NULL, 'confirme', '0', NULL, '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3');

--
-- Structure de la table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `module` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_permission` (`role_id`,`module`,`action`),
  KEY `idx_module_action` (`module`,`action`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `role_permissions`
--

INSERT INTO `role_permissions` VALUES ('1', '1', 'dashboard', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('2', '1', 'dashboard', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('3', '1', 'dashboard', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('4', '1', 'dashboard', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('5', '1', 'dashboard', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('6', '1', 'dashboard', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('7', '1', 'dashboard', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('8', '1', 'patients', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('9', '1', 'patients', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('10', '1', 'patients', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('11', '1', 'patients', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('12', '1', 'patients', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('13', '1', 'patients', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('14', '1', 'patients', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('15', '1', 'consultations', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('16', '1', 'consultations', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('17', '1', 'consultations', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('18', '1', 'consultations', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('19', '1', 'consultations', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('20', '1', 'consultations', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('21', '1', 'consultations', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('22', '1', 'rendezvous', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('23', '1', 'rendezvous', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('24', '1', 'rendezvous', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('25', '1', 'rendezvous', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('26', '1', 'rendezvous', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('27', '1', 'rendezvous', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('28', '1', 'rendezvous', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('29', '1', 'prescriptions', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('30', '1', 'prescriptions', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('31', '1', 'prescriptions', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('32', '1', 'prescriptions', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('33', '1', 'prescriptions', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('34', '1', 'prescriptions', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('35', '1', 'prescriptions', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('36', '1', 'documents', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('37', '1', 'documents', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('38', '1', 'documents', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('39', '1', 'documents', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('40', '1', 'documents', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('41', '1', 'documents', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('42', '1', 'documents', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('43', '1', 'utilisateurs', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('44', '1', 'utilisateurs', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('45', '1', 'utilisateurs', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('46', '1', 'utilisateurs', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('47', '1', 'utilisateurs', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('48', '1', 'utilisateurs', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('49', '1', 'utilisateurs', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('50', '1', 'roles', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('51', '1', 'roles', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('52', '1', 'roles', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('53', '1', 'roles', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('54', '1', 'roles', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('55', '1', 'roles', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('56', '1', 'roles', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('57', '1', 'parametres', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('58', '1', 'parametres', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('59', '1', 'parametres', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('60', '1', 'parametres', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('61', '1', 'parametres', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('62', '1', 'parametres', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('63', '1', 'parametres', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('64', '1', 'sauvegardes', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('65', '1', 'sauvegardes', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('66', '1', 'sauvegardes', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('67', '1', 'sauvegardes', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('68', '1', 'sauvegardes', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('69', '1', 'sauvegardes', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('70', '1', 'sauvegardes', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('71', '1', 'statistiques', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('72', '1', 'statistiques', 'create', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('73', '1', 'statistiques', 'edit', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('74', '1', 'statistiques', 'delete', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('75', '1', 'statistiques', 'export', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('76', '1', 'statistiques', 'import', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('77', '1', 'statistiques', 'print', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('78', '1', 'pathologies', 'view', '2025-12-22 01:13:36');
INSERT INTO `role_permissions` VALUES ('79', '1', 'pathologies', 'create', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('80', '1', 'pathologies', 'edit', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('81', '1', 'pathologies', 'delete', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('82', '1', 'pathologies', 'export', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('83', '1', 'pathologies', 'import', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('84', '1', 'pathologies', 'print', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('85', '1', 'specialites', 'view', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('86', '1', 'specialites', 'create', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('87', '1', 'specialites', 'edit', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('88', '1', 'specialites', 'delete', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('89', '1', 'specialites', 'export', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('90', '1', 'specialites', 'import', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('91', '1', 'specialites', 'print', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('92', '1', 'notifications', 'view', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('93', '1', 'notifications', 'create', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('94', '1', 'notifications', 'edit', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('95', '1', 'notifications', 'delete', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('96', '1', 'notifications', 'export', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('97', '1', 'notifications', 'import', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('98', '1', 'notifications', 'print', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('99', '1', 'audit', 'view', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('100', '1', 'audit', 'create', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('101', '1', 'audit', 'edit', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('102', '1', 'audit', 'delete', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('103', '1', 'audit', 'export', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('104', '1', 'audit', 'import', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('105', '1', 'audit', 'print', '2025-12-22 01:13:37');
INSERT INTO `role_permissions` VALUES ('107', '2', 'dashboard', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('108', '2', 'patients', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('109', '2', 'patients', 'create', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('110', '2', 'patients', 'edit', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('111', '2', 'consultations', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('112', '2', 'consultations', 'create', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('113', '2', 'consultations', 'edit', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('114', '2', 'rendezvous', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('115', '2', 'rendezvous', 'create', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('116', '2', 'rendezvous', 'edit', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('117', '2', 'prescriptions', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('118', '2', 'prescriptions', 'create', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('119', '2', 'prescriptions', 'edit', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('120', '2', 'prescriptions', 'print', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('121', '2', 'documents', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('122', '2', 'documents', 'create', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('123', '2', 'documents', 'edit', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('124', '2', 'statistiques', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('125', '2', 'pathologies', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('126', '2', 'specialites', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('127', '2', 'notifications', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('128', '3', 'dashboard', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('129', '3', 'patients', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('130', '3', 'patients', 'create', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('131', '3', 'rendezvous', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('132', '3', 'rendezvous', 'create', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('133', '3', 'rendezvous', 'edit', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('134', '3', 'rendezvous', 'delete', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('135', '3', 'documents', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('136', '3', 'documents', 'create', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('137', '3', 'notifications', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('138', '4', 'dashboard', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('139', '4', 'patients', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('140', '4', 'consultations', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('141', '4', 'rendezvous', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('142', '4', 'documents', 'view', '2025-12-22 01:16:23');
INSERT INTO `role_permissions` VALUES ('143', '4', 'notifications', 'view', '2025-12-22 01:16:23');

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`),
  KEY `created_by` (`created_by`),
  KEY `idx_role_name` (`role_name`),
  CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `roles`
--

INSERT INTO `roles` VALUES ('1', 'admin', 'Accès complet au système', '1', '2025-12-22 01:13:36', NULL);
INSERT INTO `roles` VALUES ('2', 'docteur', 'Médecin avec accès aux patients et consultations', '1', '2025-12-22 01:13:37', NULL);
INSERT INTO `roles` VALUES ('3', 'secretaire', 'Personnel administratif', '1', '2025-12-22 01:13:37', NULL);
INSERT INTO `roles` VALUES ('4', 'assistant', 'Assistant aux médecins', '1', '2025-12-22 01:13:37', NULL);

--
-- Structure de la table `salle_attente`
--

DROP TABLE IF EXISTS `salle_attente`;
CREATE TABLE `salle_attente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `docteur_id` int(11) DEFAULT NULL,
  `motif` text,
  `notes` text,
  `urgence` tinyint(1) DEFAULT '0',
  `statut` enum('en_attente','appele','retire') DEFAULT 'en_attente',
  `added_by` int(11) DEFAULT NULL,
  `called_by` int(11) DEFAULT NULL,
  `removed_by` int(11) DEFAULT NULL,
  `added_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `called_at` timestamp NULL DEFAULT NULL,
  `removed_at` timestamp NULL DEFAULT NULL,
  `raison_retrait` text,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `docteur_id` (`docteur_id`),
  KEY `added_by` (`added_by`),
  KEY `called_by` (`called_by`),
  KEY `removed_by` (`removed_by`),
  KEY `idx_salle_attente_statut` (`statut`),
  KEY `idx_salle_attente_urgence` (`urgence`),
  KEY `idx_salle_attente_added_at` (`added_at`),
  CONSTRAINT `salle_attente_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salle_attente_ibfk_2` FOREIGN KEY (`docteur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salle_attente_ibfk_3` FOREIGN KEY (`added_by`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salle_attente_ibfk_4` FOREIGN KEY (`called_by`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salle_attente_ibfk_5` FOREIGN KEY (`removed_by`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `salle_attente`
--

INSERT INTO `salle_attente` VALUES ('1', '8', '2', 'consultation', NULL, '0', 'appele', '4', '4', NULL, '2026-05-24 16:14:35', '2026-05-24 16:14:42', NULL, NULL, '2026-05-24 16:14:42');
INSERT INTO `salle_attente` VALUES ('2', '8', '2', 'soigner', NULL, '0', 'appele', '4', '4', NULL, '2026-05-24 16:15:01', '2026-05-24 16:22:44', NULL, NULL, '2026-05-24 16:22:44');
INSERT INTO `salle_attente` VALUES ('3', '8', '5', 'malade consultation', NULL, '0', 'en_attente', '4', NULL, NULL, '2026-05-24 16:23:05', NULL, NULL, NULL, '2026-05-24 16:23:05');
INSERT INTO `salle_attente` VALUES ('4', '6', '7', 'consultation', NULL, '0', 'en_attente', '4', NULL, NULL, '2026-05-24 16:23:24', NULL, NULL, NULL, '2026-05-24 16:23:24');

--
-- Structure de la table `specialites`
--

DROP TABLE IF EXISTS `specialites`;
CREATE TABLE `specialites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `description` text,
  `couleur` varchar(7) DEFAULT '#3b82f6',
  `icon` varchar(50) DEFAULT 'fas fa-stethoscope',
  `statut` enum('active','inactive') DEFAULT 'active',
  `date_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `nom` (`nom`),
  KEY `idx_code` (`code`),
  KEY `idx_statut` (`statut`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

--
-- Données de la table `specialites`
--

INSERT INTO `specialites` VALUES ('1', 'CARDIO', 'Cardiologie', 'Spécialité médicale traitant les troubles cardiaques et vasculaires', '#ef4444', 'fas fa-heartbeat', 'active', '2025-12-20 00:41:53');
INSERT INTO `specialites` VALUES ('2', 'DERMA', 'Dermatologie', 'Spécialité médicale traitant les maladies de la peau', '#8b5cf6', 'fas fa-allergies', 'active', '2025-12-20 00:41:53');
INSERT INTO `specialites` VALUES ('3', 'NEURO', 'Neurologie', 'Spécialité médicale traitant les troubles neurologiques', '#3b82f6', 'fas fa-brain', 'active', '2025-12-20 00:41:53');
INSERT INTO `specialites` VALUES ('4', 'PEDIA', 'Pédiatrie', 'Spécialité médicale traitant les enfants et adolescents', '#10b981', 'fas fa-baby', 'active', '2025-12-20 00:41:53');
INSERT INTO `specialites` VALUES ('5', 'GYNECO', 'Gynécologie', 'Spécialité médicale traitant la santé féminine', '#ec4899', 'fas fa-female', 'active', '2025-12-20 00:41:53');
INSERT INTO `specialites` VALUES ('6', 'RADIO', 'Radiologie', 'Spécialité médicale utilisant l\'imagerie médicale', '#f59e0b', 'fas fa-x-ray', 'active', '2025-12-20 00:41:53');
INSERT INTO `specialites` VALUES ('7', 'PSY', 'Psychiatrie', 'Spécialité médicale traitant les troubles mentaux', '#6366f1', 'fas fa-brain', 'active', '2025-12-20 00:41:53');
INSERT INTO `specialites` VALUES ('8', 'ORTHO', 'Orthopédie', 'Spécialité chirurgicale traitant le système musculo-squelettique', '#84cc16', 'fas fa-bone', 'active', '2025-12-20 00:41:53');
INSERT INTO `specialites` VALUES ('9', 'OPHTAL', 'Ophtalmologie', 'Spécialité médicale traitant les yeux', '#06b6d4', 'fas fa-eye', 'active', '2025-12-20 00:41:53');
INSERT INTO `specialites` VALUES ('10', 'GENERAL', 'Médecine Générale', 'Médecine générale et soins primaires', '#64748b', 'fas fa-user-md', 'active', '2025-12-20 00:41:53');

--
-- Structure de la table `stock_peremption`
--

DROP TABLE IF EXISTS `stock_peremption`;
CREATE TABLE `stock_peremption` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medicament_id` int(11) NOT NULL,
  `lot` varchar(100) DEFAULT NULL,
  `date_peremption` date DEFAULT NULL,
  `quantite` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `medicament_id` (`medicament_id`),
  KEY `idx_stock_peremption_date` (`date_peremption`),
  CONSTRAINT `stock_peremption_ibfk_1` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Structure de la table `tache_comments`
--

DROP TABLE IF EXISTS `tache_comments`;
CREATE TABLE `tache_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tache_id` int(11) NOT NULL,
  `commentaire` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tache_id` (`tache_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `tache_comments_ibfk_1` FOREIGN KEY (`tache_id`) REFERENCES `taches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tache_comments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Structure de la table `taches`
--

DROP TABLE IF EXISTS `taches`;
CREATE TABLE `taches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(200) NOT NULL,
  `description` text,
  `priorite` enum('haute','moyenne','basse') DEFAULT 'moyenne',
  `statut` enum('a_faire','en_cours','termine','annule','supprime') DEFAULT 'a_faire',
  `date_echeance` date DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_taches_statut` (`statut`),
  KEY `idx_taches_priorite` (`priorite`),
  KEY `idx_taches_assigned` (`assigned_to`),
  KEY `idx_taches_date_echeance` (`date_echeance`),
  CONSTRAINT `taches_ibfk_1` FOREIGN KEY (`assigned_to`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `taches_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Structure de la table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('docteur','secretaire','assistant','admin') COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialite` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adresse` text COLLATE utf8mb4_unicode_ci,
  `date_naissance` date DEFAULT NULL,
  `sexe` enum('M','F') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statut` enum('actif','inactif','suspendu') COLLATE utf8mb4_unicode_ci DEFAULT 'inactif',
  `jours_consultation` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `derniere_connexion` datetime DEFAULT NULL,
  `date_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `signature` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_modification` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `verification_code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_code` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires_at` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `otp_verified` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_statut` (`statut`),
  KEY `idx_email` (`email`),
  KEY `idx_nom_prenom` (`nom`,`prenom`),
  KEY `verification_code` (`verification_code`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` VALUES ('1', 'Admin', 'System', 'admin@medical.com', '$2y$10$AvIgI.kfNCa4RT9uBh4fPedH3T.G.92ZHk5EAtIT3QI5cSK7K/u4m', 'admin', NULL, '+12345678910', '', '1994-01-22', 'M', 'uploads/avatars/avatar_1_1779634780.jpeg', 'actif', NULL, '2026-05-25 12:53:38', '2025-12-20 00:41:53', NULL, '2026-05-25 12:53:38', NULL, NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('2', 'Dupont', 'Jean', 'jean.dupont@medical.com', '$2y$10$ikCSUHureSSiYliQ8mgK/uReygTVfUEtcB5zii3lSjct4YnaLNyCq', 'docteur', 'Cardiologie', '+1234567890', '', NULL, NULL, NULL, 'actif', NULL, '2025-12-27 20:51:22', '2025-12-20 00:41:53', NULL, '2025-12-27 20:51:22', NULL, NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('3', 'Martin', 'Sophie', 'sophie.martin@medical.com', '$2y$10$RQCo24mb2HSwT8iho.yIeOybb19006XYdssNYzpCHgED7Hw57rHym', 'secretaire', NULL, '+33123456791', NULL, NULL, NULL, NULL, 'actif', NULL, NULL, '2025-12-20 00:41:53', NULL, '2025-12-20 00:49:18', NULL, NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('4', 'Bernard', 'Pierre', 'pierre.bernard@medical.com', '$2y$10$D2P9CXwxfHSGKZGBGrIT3u0W90s5z80N.RwEPxOPIdF4QkKO16j9C', 'assistant', 'Cardiologie', '+33123456792', '', NULL, NULL, 'uploads/avatars/avatar_4_1779637443.png', 'actif', NULL, '2026-05-24 14:32:01', '2025-12-20 00:41:53', NULL, '2026-05-24 17:44:03', NULL, NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('5', 'Leroy', 'Marie', 'marie.leroy@medical.com', '$2y$10$5Ftwbu3tdpgWhfcZvUal.eyEKwEPCDJpPZ31QAWrytfK8JPwCpshe', 'docteur', 'Dermatologie', '+33123456793', NULL, NULL, NULL, NULL, 'actif', NULL, NULL, '2025-12-20 00:41:53', NULL, '2025-12-20 00:49:18', NULL, NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('6', 'Petit', 'Luc', 'luc.petit@medical.com', '$2y$10$hJrmvR7PBP3agdiWsn9PjuI7k4jl/OQwCS9IJsJ/LZE/yzTwk0jZa', 'assistant', 'Dermatologie', '+12345678910', 'mon adresse', '0000-00-00', '', NULL, 'actif', NULL, '2025-12-27 20:51:10', '2025-12-20 00:41:53', NULL, '2025-12-27 20:51:10', NULL, NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('7', 'Robert', 'Alice', 'alice.robert@medical.com', '$2y$10$lXJ14ACv1cptL/FWZ0b91OPY3HUDZU3bxlGUtgp6L.ZitrCiwjO8q', 'docteur', 'Médecine Générale', '+33123456795', NULL, NULL, NULL, NULL, 'actif', NULL, NULL, '2025-12-20 00:41:53', NULL, '2025-12-20 00:49:19', NULL, NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('8', 'Simon', 'Thomas', 'thomas.simon@medical.com', '$2y$10$z6PFf/.nTG8F1t4hncFvvuZKAhhdUqJD8ByS7dIJFoK8Tb4nLjAAi', 'secretaire', NULL, '+012345678910', '', '0000-00-00', '', NULL, 'actif', NULL, '2025-12-24 20:55:55', '2025-12-20 00:41:53', NULL, '2025-12-26 00:12:56', NULL, NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('9', 'daniel', 'kojo', 'kojo.don@gmail.com', '$2y$10$HQrfu0nl5j10anjpO0ido.kycHTL8xTKmZAaMFb4/YOqAkoJULrre', 'assistant', NULL, '+1234567890', NULL, NULL, NULL, NULL, 'actif', NULL, NULL, '2025-12-25 00:08:13', NULL, '2025-12-25 00:51:33', '0e6f81c14defc10a4f8b8c81e1a6d6b9', NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('10', 'daniel', 'kojo', 'kojo@gmail.com', '$2y$10$CUDWY/nXP9ZlzgCP0xf/EuvVuBZms.iSUXZ0mSSCidtft4fd0mfdy', 'assistant', 'medicine general', '1234567890', NULL, NULL, NULL, NULL, 'actif', NULL, '2025-12-25 00:56:00', '2025-12-25 00:09:46', NULL, '2025-12-25 00:56:00', 'd6acf648d96c5d358ae6112e64222e92', NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('14', 'karume', 'Kojocampany', 'chalij68@gmail.com', '$2y$10$FDVlsL0PrlA5wVcumEt3cezaMSMgEkF3/KK8oN0N8a8KB4t4ZJPoK', 'assistant', NULL, '+12369227132', '', '0000-00-00', 'M', NULL, 'actif', NULL, '2026-01-04 17:14:10', '2025-12-25 00:52:18', NULL, '2026-01-04 18:44:45', NULL, NULL, NULL, NULL, '0');
INSERT INTO `utilisateurs` VALUES ('15', 'karume', 'daniel', 'karume@medical.com', '$2y$10$Rt31thX1P7GtKsG9/RfY7uhv1NPaf736xtYiq2HjShgm1GOlEx00G', 'assistant', 'infirmiere', '+33 868578', NULL, NULL, NULL, NULL, 'actif', NULL, NULL, '2026-05-22 13:14:43', NULL, '2026-05-22 13:15:49', NULL, '872185', '2026-05-22 13:24:43', NULL, '0');

--
-- Structure de la table `view_log_statistics`
--

DROP TABLE IF EXISTS `view_log_statistics`;
;

--
-- Données de la table `view_log_statistics`
--

INSERT INTO `view_log_statistics` VALUES ('2026-05-24', '1', '1', '1', '0', '0', '0');
INSERT INTO `view_log_statistics` VALUES ('2026-05-22', '3', '2', '1', '0', '0', '1');
INSERT INTO `view_log_statistics` VALUES ('2026-05-20', '2', '2', '1', '0', '0', '0');

--
-- Structure de la table `vue_consultations_mensuelles`
--

DROP TABLE IF EXISTS `vue_consultations_mensuelles`;
;

--
-- Données de la table `vue_consultations_mensuelles`
--

INSERT INTO `vue_consultations_mensuelles` VALUES ('2026-06', '3', '3', '2', '2', '0', '1', '0');
INSERT INTO `vue_consultations_mensuelles` VALUES ('2026-05', '1', '1', '1', '0', '0', '1', '0');
INSERT INTO `vue_consultations_mensuelles` VALUES ('2024-01', '5', '5', '3', '5', '0', '0', '0');

--
-- Structure de la table `vue_docteurs_activite`
--

DROP TABLE IF EXISTS `vue_docteurs_activite`;
;

--
-- Données de la table `vue_docteurs_activite`
--

INSERT INTO `vue_docteurs_activite` VALUES ('2', 'Jean Dupont', 'Cardiologie', '5', '2024-01-16 10:30:00', '2026-06-15 09:00:00', '5', '60.0000');
INSERT INTO `vue_docteurs_activite` VALUES ('5', 'Marie Leroy', 'Dermatologie', '2', '2024-01-17 14:00:00', '2024-01-19 15:30:00', '2', '100.0000');
INSERT INTO `vue_docteurs_activite` VALUES ('7', 'Alice Robert', 'Médecine Générale', '2', '2024-01-20 10:00:00', '2026-06-28 14:30:00', '2', '100.0000');

--
-- Structure de la table `vue_patients_derniere_consultation`
--

DROP TABLE IF EXISTS `vue_patients_derniere_consultation`;
;

--
-- Données de la table `vue_patients_derniere_consultation`
--

INSERT INTO `vue_patients_derniere_consultation` VALUES ('1', 'PAT-202401-0001', 'Durand', 'Marie', '1985-06-15', 'F', NULL, '123 Rue de Paris', 'Paris', '75001', 'France', '+33612345678', NULL, 'marie.durand@email.com', NULL, 'celibataire', '0', 'A+', NULL, NULL, NULL, NULL, NULL, 'Hypertension familiale, Cholestérol', 'Pénicilline, Arachides', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3', '2026-06-15 09:00:00', 'Hypertension stable sous traitement', 'Jean', 'Dupont');
INSERT INTO `vue_patients_derniere_consultation` VALUES ('2', 'PAT-202401-0002', 'Leroy', 'Paul', '1978-03-22', 'M', NULL, '456 Avenue Victor Hugo', 'Lyon', '69002', 'France', '+33687654321', NULL, 'paul.leroy@email.com', NULL, 'celibataire', '0', 'O+', NULL, NULL, NULL, NULL, NULL, 'Diabète type 2, Cholestérol', 'Aucune', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3', '2024-01-16 10:30:00', 'Angor stable, pas d\'urgence', 'Jean', 'Dupont');
INSERT INTO `vue_patients_derniere_consultation` VALUES ('3', 'PAT-202401-0003', 'Petit', 'Julie', '1992-11-30', 'F', NULL, '789 Boulevard Saint-Germain', 'Marseille', '13001', 'France', '+33611223344', NULL, 'julie.petit@email.com', NULL, 'celibataire', '0', 'B+', NULL, NULL, NULL, NULL, NULL, 'Asthme depuis l\'enfance, Eczéma', 'Acariens, Pollen, Poils de chat', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '8', '2024-01-17 14:00:00', 'Eczéma atopique', 'Marie', 'Leroy');
INSERT INTO `vue_patients_derniere_consultation` VALUES ('4', 'PAT-202401-0004', 'Moreau', 'Thomas', '1965-08-12', 'M', NULL, '321 Rue de la République', 'Toulouse', '31000', 'France', '+33699887766', NULL, 'thomas.moreau@email.com', NULL, 'celibataire', '0', 'AB+', NULL, NULL, NULL, NULL, NULL, 'Opération genou 2018, Hypertension', 'Iode, Crustacés', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3', '2024-01-18 11:00:00', 'Diabète équilibré', 'Jean', 'Dupont');
INSERT INTO `vue_patients_derniere_consultation` VALUES ('5', 'PAT-202401-0005', 'Simon', 'Claire', '1972-12-05', 'F', NULL, '654 Rue du Commerce', 'Lille', '59000', 'France', '+33655443322', NULL, 'claire.simon@email.com', NULL, 'celibataire', '0', 'A-', NULL, NULL, NULL, NULL, NULL, 'Migraines chroniques, Dépression', 'Aspirine, Ibuprofène', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '8', '2026-06-02 09:00:00', '', 'Jean', 'Dupont');
INSERT INTO `vue_patients_derniere_consultation` VALUES ('6', 'PAT-202401-0006', 'Dubois', 'Marc', '1988-07-19', 'M', NULL, '987 Avenue des Champs-Élysées', 'Paris', '75008', 'France', '+33666778899', NULL, 'marc.dubois@email.com', NULL, 'celibataire', '0', 'O-', NULL, NULL, NULL, NULL, NULL, 'Sportif, Aucun antécédent', 'Aucune', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '3', '2026-05-24 09:00:00', '', 'Jean', 'Dupont');
INSERT INTO `vue_patients_derniere_consultation` VALUES ('7', 'PAT-202401-0007', 'Laurent', 'Sophie', '1995-04-25', 'F', NULL, '159 Rue de la Liberté', 'Bordeaux', '33000', 'France', '+33622334455', NULL, 'sophie.laurent@email.com', NULL, 'celibataire', '0', 'B-', NULL, NULL, NULL, NULL, NULL, 'Allergies saisonnières', 'Pollens, Moisissures', NULL, NULL, NULL, 'actif', '2025-12-20 00:41:53', '2025-12-20 00:41:53', '8', '2026-06-28 14:30:00', 'Allergies saisonnières confirmées', 'Alice', 'Robert');
INSERT INTO `vue_patients_derniere_consultation` VALUES ('8', 'PAT-202605-0001', 'dd', 'gg', '2026-05-26', 'M', NULL, 'bbbbbbbbbbbbb', 'vvvvvvvvvvvvvvv', '1111111111', 'France', '+33123456792', NULL, 'chalij68@gmail.com', NULL, 'celibataire', '0', 'O-', NULL, NULL, NULL, NULL, NULL, 'dddddddddddddddd', 'ddddddddd', NULL, NULL, NULL, 'actif', '2026-05-24 16:03:24', '2026-05-24 16:03:24', '4', NULL, NULL, NULL, NULL);

--
-- Structure de la table `vue_rdv_a_venir`
--

DROP TABLE IF EXISTS `vue_rdv_a_venir`;
;

--
-- Structure de la table `vue_statistiques_patients`
--

DROP TABLE IF EXISTS `vue_statistiques_patients`;
;

--
-- Données de la table `vue_statistiques_patients`
--

INSERT INTO `vue_statistiques_patients` VALUES ('8', '4', '4', '37.7500', '1', '7', '0', '0', '0');

SET FOREIGN_KEY_CHECKS=1;
